import time
import pandas as pd
import numpy as np

CITY_DATA = { 'chicago': 'chicago.csv',
              'new york city': 'new_york_city.csv',
              'washington': 'washington.csv' }

def get_filters():
    """
    Asks user to specify a city, month, and day to analyze.

    Returns:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    """
    print('Hello! Let\'s explore some US bikeshare data!')
    # get user input for city (chicago, new york city, washington). HINT: Use a while loop to handle invalid inputs

    while True:
        city = input("\nSelect one city from (Chicago, New York City or Washington).\nPlease enter your selection here: ").lower().strip()
        if city not in ['chicago', 'new york city', 'washington']:
            print("\nOops! Your city input is out of our scope!.\nPlease try again to enter the city name from the above choices.")
            continue
        else:
            break
    # get user input for month (all, january, february, ... , june)
    months = ['january', 'february', 'march', 'april', 'may', 'june']

    while True:
        month = input("\nEnter one month from (January to June) to get filtered data for this month or select (all) to get the whole data for these months\
 without filtering\nPlease enter your selection here: ").lower().strip()
        if month != 'all' and month not in months:
            print('\nOops! You shall the right month name!\nPlease try again!')
            continue
        else:
            break
    # get user input for day of week (all, monday, tuesday, ... sunday)
    weekdays = ['saturday', 'sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday']

    while True:
        day = input("\nEnter one weekday from (Saturday to Friday) to get filtered data for this day or select (all) to get all data for the whole\
 weekdays without filtering.\nPlease enter your selection here:  ").lower().strip()
        if day != 'all' and day not in weekdays:
            print('\nOops! You shall the right day name!\nPlease try again!')
            continue
        else:
            break
    print('-'*40)
    print('\nYour selection is as follows:\nSelected City is: ({}).\nSelected month is: ({}).\nSelected weekday is: ({}).'.format(city, month, day))
    return city, month, day



def load_data(city, month, day):
    """
    Loads data for the specified city and filters by month and day if applicable.

    Args:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    Returns:
        df - Pandas DataFrame containing city data filtered by month and day
    """

    df = pd.read_csv(CITY_DATA[city])

    # convert the Start Time column to datetime
    df['Start Time'] = pd.to_datetime(df['Start Time'])

    # filter by month and day to create the new dataframe
    df['month'] = df['Start Time'].dt.month
    df['day'] = df['Start Time'].dt.weekday
    months = ['january', 'february', 'march', 'april', 'may', 'june']
    weekdays = ['saturday', 'sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday']
    if month != 'all':
        # use the index of the months list to get the corresponding int
        month = months.index(month) + 1
        # filter by month to create the new dataframe
        df = df[df['month'] == month]
    if day != 'all':
        day = weekdays.index(day)
        # filter by day of week to create the new dataframe
        df = df[df['day'] == day]
    return df

def data_lines(df):

    """"
    This function is created to load data lines when requested by entering 'y' (Yes) for the first iteration
    to load five data lines from dataframe (df) and continue to load another five lines by entering 'y' again
    and so on till reject loading by entering 'n' (No).

    The below codes address any user input's errors by re-asking the user to enter the correct choice 'y' or 'n'
    and also print a warning clause to direct the user to the correct choices.
    """
    loading_data = input('Do you want to load only 5 line of raw inputs, (y) or (n) ').lower().strip()
    i = 0
    while loading_data != 'y' and loading_data != 'n':
        print('Ooops! please enter (y) for Yes and (n) for No.')
        loading_data = input('Do you want to load only 5 line of raw inputs, (y) or (n) ').lower().strip()
        if loading_data != 'y' and loading_data != 'n':
            continue
        elif loading_data == 'n':
            break
    while loading_data == 'y':
        i += 5
        print(df.head(i))
        loading_more_data_lines = input('Do you want to load another 5 line of raw inputs, (y) or (n) ').lower().strip()
        if loading_more_data_lines == 'y':
            continue
        while loading_more_data_lines != 'y' and loading_more_data_lines != 'n':
            print('Ooops! Please enter (y) for Yes and (n) for No.')
            loading_more_data_lines = input('Do you want to load another 5 line of raw inputs, (y) or (n) ').lower().strip()
            if loading_more_data_lines != 'y' and loading_more_data_lines != 'n':
                continue
        if loading_more_data_lines == 'n':
             break

def time_stats(df):

    """Displays statistics on the most frequent times of travel."""
    while True:
        time_statstics = input('\nDo you want to load most frequent times of travel?\nPlease enter (y) for Yes and (n) for No: ').lower().strip()

        if time_statstics == 'y':
            print('\nCalculating The Most Frequent Times of Travel...\n')
            start_time = time.time()

            # find the most common start hour
            months = ['january', 'february', 'march', 'april', 'may', 'june']
            most_common_start_month = months [(df['month'].mode()[0] -1)]

            # display the most common day of week
            weekdays = ['saturday', 'sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday']
            most_common_start_weekday = weekdays [df['day'].mode()[0]]

            # display the most common start hour
            # extract hour from the Start Time column to create an hour column
            df['hour'] = df['Start Time'].dt.hour
            # find the most common start hour
            most_common_start_hour = df['hour'].mode()[0]

            print('Most common start month is: ({}).'.format(most_common_start_month))
            print('Most common start weekday is: ({}).'.format(most_common_start_weekday))
            print('Most common start hour is: ({}:00).'.format(most_common_start_hour))
            print("\nThis took %s seconds." % (time.time() - start_time))
            print('-'*40)
            break
        elif time_statstics != 'y' and time_statstics != 'n':
            print('try again with entering (y) for Yes and (n) for No: ')
            continue
        else:
            break

def station_stats(df):
    """Displays statistics on the most popular stations and trip."""
    while True:
        stations_statistics = input('\nDo you want to load most popular station and trip ?\nPlease enter (y) for Yes and (n) for No: ').lower().strip()
        if stations_statistics == 'y':
            print('\nCalculating The Most Popular Stations and Trip...\n')
            start_time = time.time()
            # display most commonly used start station
            most_common_start_station = df['Start Station'].mode()[0]
            # display most commonly used end station
            most_common_end_station = df['End Station'].mode()[0]
            # display most frequent combination of start station and end station trip
            most_frequent_combination_start_and_end_station = (df['Start Station'] + ' - ' + df['End Station']).mode()[0]
            print('Most common start station is: ({}).'.format(most_common_start_station))
            print('Most common end station is:({}).'.format(most_common_end_station))
            print('Most common combination of start & end stations is: ({}).'.format(most_frequent_combination_start_and_end_station))
            print("\nThis took %s seconds." % (time.time() - start_time))
            print('-'*40)
            break
        elif stations_statistics != 'y' and stations_statistics !='n':
            print('try again with entering (y) for Yes and (n) for No: ')
            continue
        else:
            break

def trip_duration_stats(df):

    """Displays statistics on the total and average trip duration."""
    while True:
        trip_duration_statistics = input('\nDo you want to load trip duration ?\nPlease enter (y) for Yes and (n) for No: ').lower().strip()
        if trip_duration_statistics == 'y':
            print('\nCalculating Trip Duration...\n')
            start_time = time.time()

            # display total travel time
            total_time = (df['Trip Duration'].sum())
            # display mean travel time
            mean_time = df['Trip Duration'].mean()

            print('The total travel time is: ({}) seconds.'.format(total_time))
            print('The mean travel time is: ({}) seconds.'.format(mean_time))
            print("\nThis took %s seconds." % (time.time() - start_time))
            print('-'*40)
            break
        elif trip_duration_statistics != 'y' and trip_duration_statistics != 'n':
            print('try again with entering (y) for Yes and (n) for No: ')
            continue
        else:
            break


def user_stats(df):
    """Displays statistics on bikeshare users."""
    while True:
        user_statistics = input('\nDo you want to load user statistics?\nplease enter (y) for Yes and (n) for No: ').lower().strip()
        if user_statistics == 'y':
            print('\nCalculating User Stats...\n')
            start_time = time.time()
            # Display counts of user types
            counts_of_user_types = df['User Type'].value_counts()
            print('\nCount of user type is as follows:\n', counts_of_user_types)
            try:
               # Display counts of gender
               count_of_gender = df['Gender'].value_counts()
               # Display earliest, most recent, and most common year of birth
               earliest_birth_year = int(df['Birth Year'].min())
               most_recent_birth_year = int(df['Birth Year'].max())
               most_common_birth_year = int(df['Birth Year'].mode()[0])
               print('Count of Gender is as follows:\n', count_of_gender)
               print('Earliest birth year is: ({}).\nMost recent birth year is: ({}).\n Most common birth year is: ({}).'
.format(earliest_birth_year, most_recent_birth_year, most_common_birth_year))
               print("\nThis took %s seconds." % (time.time() - start_time))
               print('-'*40)

            except KeyError:
                print("\nOops, There is no available data concerining the selected city.\nPlease, try finding this data with other cities.")
            break
        elif user_statistics != 'y' and user_statistics != 'n':
            print('try again with entering (y) for Yes and (n) for No: ')
            continue
        else:
            break

def main():

    while True:
        city, month, day = get_filters()
        df = load_data(city, month, day)
        data_lines(df)
        time_stats(df)
        station_stats(df)
        trip_duration_stats(df)
        user_stats(df)

        restart = input('\nWould you like to restart?\nEnter (y) for Yes or (n) for No: ')
        if restart.lower().strip() != 'y':
            break


if __name__ == "__main__":
    main()







